from extra_file import print_stuff

if __name__=="__main__":
    print_stuff("hello world")
