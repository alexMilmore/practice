Very basic python package for practice
