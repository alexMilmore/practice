def print_stuff(words: str):
    print(words)
